# KernelLab

KernelLab is a pure-Python OS simulator with a FastAPI dashboard. It executes CPU scheduling, memory allocation, virtual memory, deadlock, and synchronization experiments; persists every run in SQLite; and compares recorded algorithms.

## Run it

```bash
docker compose up --build
# open http://localhost:8000
```

For local development, create a virtual environment, `pip install -r requirements.txt`, then run `uvicorn kernellab.api:app --reload`. Run `pytest` for the hand-computed algorithm tests.

## Architecture

```text
Dashboard / API -> Kernel dispatcher -> algorithm modules -> SimulationResult
       |                                      |                 |
       +--------------------------------------> SQLite RunStore <-+
```

`POST /run` accepts a module, algorithm, and JSON workload. The dashboard exposes CPU scheduling, memory allocation, virtual memory, deadlock, and synchronization presets; every workload is editable JSON. `GET /history` filters recorded runs, `GET /compare` ranks results using a chosen metric, and `GET /stats` returns SQL aggregates. `POST /snapshots/psutil` captures host-visible processes; container deployments use psutil or uploaded/replayed data, not pywin32.

## Modules and complexity

| Module | Included algorithms | Representative complexity |
|---|---|---|
| CPU | FCFS, SJF, SRTF, Round Robin, Priority | FCFS O(n), heap scheduling O(n log n) |
| Memory | First Fit, Best Fit, Worst Fit, Buddy | O(blocks x requests); buddy uses free lists |
| VM | FIFO, LRU, Clock, Optimal | O(references x frames) in this visual simulator |
| Deadlock | DFS wait-for graph, Banker's safety check | O(V + E), O(processes² x resources) |
| Sync | producer-consumer, ordered dining philosophers, protected thread-race lab | O(operations), O(rounds x philosophers) |

## Database

The schema has `workloads`, `runs`, `metrics`, `events`, and `snapshots`. The composite index `(workload_id, module)` speeds per-workload comparisons. To inspect it:

```sql
EXPLAIN QUERY PLAN SELECT * FROM runs WHERE workload_id = 1 AND module = 'cpu';
```

Reusable join, aggregation, and window-function examples are in [sql/analytics.sql](sql/analytics.sql).

## Example API request

```bash
curl -X POST http://localhost:8000/run -H "content-type: application/json" -d '{"module":"cpu","algorithm":"round_robin","params":{"quantum":2,"processes":[{"pid":"P1","arrival":0,"burst":5},{"pid":"P2","arrival":1,"burst":3}]}}'
```

## Windows host snapshot

The container can only see Linux-container processes. To capture real Windows processes, run this from the project directory in PowerShell:

```powershell
.\scripts\capture_windows_snapshot.ps1
Invoke-RestMethod http://localhost:8000/snapshots/import -Method Post -ContentType application/json -InFile .\work\windows-snapshot.json
```

The script produces a CPU workload normalized from process CPU time and a memory workload normalized from RSS. Use the generated `cpu` and `memory` objects with `POST /run` (for example, First Fit vs Best Fit or SRTF vs Round Robin); it preserves the raw snapshot separately in SQLite. Repeating a workload with another algorithm now reuses its workload ID, so `/compare?workload_id=...` is a true like-for-like ranking.

## Scope note

This project deliberately excludes file systems, disk scheduling, IPC, and machine learning. The `SystemProbe` abstraction supplies `PsutilProbe`, `FakeProbe`, and a host-only `WindowsProbe` extension that reads `pywin32` when it is installed; Docker keeps the portable psutil path.
